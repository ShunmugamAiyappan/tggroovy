package com.game.tambola

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class TambolaApplication {

	static void main(String[] args) {
		SpringApplication.run(TambolaApplication, args)
	}

}
