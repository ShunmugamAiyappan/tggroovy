package com.game.tambola

class Game {
    Ticket ticket

    // Constructor
    Game(Ticket ticket) {
        this.ticket = ticket
    }

    // Public method to check if a line is a winning line
    public boolean isWinningLine(int lineIndex) {
        // Check if all numbers in the line are either null or crossed
        return ticket.numbers[lineIndex].every { it == null || ticket.isNumberCrossed(it) }
    }

    // Public method to check if the top line is a winning line
    public boolean isTopLine() {
        return isWinningLine(0)
    }

    // Public method to check if the middle line is a winning line
    public boolean isMiddleLine() {
        return isWinningLine(1)
    }

    // Public method to check if the bottom line is a winning line
    public boolean isBottomLine() {
        return isWinningLine(2)
    }

    // Public method to check if all numbers in the full house are crossed
    public boolean isFullHouse() {
        // Flatten the 2D array and check if all numbers are either null or crossed
        return ticket.numbers.flatten().every { it == null || ticket.isNumberCrossed(it) }
    }

    // Public method to check if the first five numbers are crossed (Early Five)
    public boolean isEarlyFive() {
        // Check if the first 5 crossed numbers are 5
        return ticket.crossedNumbers.take(5).size() == 5
    }
}
