package com.game.tambola

class ClaimValidator {

    List<Integer> announcedNumbers
    Ticket ticket
    Game game

    int lastAnnouncedNumber = announcedNumbers[-1]
    int previouslyCrossedCount

    ClaimValidator(List<Integer> announcedNumbers, Ticket ticket) {
        this.announcedNumbers = announcedNumbers
        this.ticket = ticket
        this.game = new Game(ticket)
    }

    boolean  isRowCompleteWithLastAnnounced(int lineIndex) {
        List<Integer> line = ticket.getNumbersInLine(lineIndex).findAll { it != null }
        boolean allCrossed = line.every { ticket.isNumberCrossed(it) }
        return allCrossed && line.contains(lastAnnouncedNumber)
    }

    String validateClaim(String claim) {
        // Cross all announced numbers on the ticket
        announcedNumbers.each { ticket.crossNumber(it) }
        previouslyCrossedCount = ticket.crossedNumbers.size() - 1
        switch (claim) {
            case 'Top Row':
                return isRowCompleteWithLastAnnounced(0) ? 'Accepted' : 'Rejected'
            case 'Middle Row':
                return isRowCompleteWithLastAnnounced(1) ? 'Accepted' : 'Rejected'
            case 'Bottom Row':
                return isRowCompleteWithLastAnnounced(2) ? 'Accepted' : 'Rejected'
            case 'Full House':
                return game.isFullHouse() && ticket.isNumberCrossed(lastAnnouncedNumber) ? 'Accepted' : 'Rejected'
            case 'Early Five':
                return previouslyCrossedCount == 4 && ticket.isNumberCrossed(lastAnnouncedNumber) ? 'Accepted' : 'Rejected'
            default:
                return 'Rejected'
        }
    }
}

