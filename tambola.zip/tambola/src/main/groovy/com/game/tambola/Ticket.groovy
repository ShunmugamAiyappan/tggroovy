package com.game.tambola

class Ticket {
    List<List<Integer>> numbers  // 2D list representing rows and numbers
    Set<Integer> crossedNumbers  // Set of crossed numbers

    // Constructor
    Ticket(List<List<Integer>> numbers) {
        this.numbers = numbers
        this.crossedNumbers = new HashSet<>()
    }

    // Public method to cross a number on the ticket
    public void crossNumber(int number) {
        crossedNumbers.add(number)
    }

    // Public method to check if a number has been crossed
    public boolean isNumberCrossed(int number) {
        return crossedNumbers.contains(number)
    }

    // Public method to get the set of crossed numbers
    public Set<Integer> getCrossedNumbers() {
        return crossedNumbers
    }

    // Public method to get all numbers in a specific row (line index)
    public List<Integer> getNumbersInLine(int lineIndex) {
        return numbers[lineIndex]
    }
}