package com.game.tambola

import spock.lang.Ignore
import spock.lang.Specification

class TicketSpec extends Specification {

    def "should create a Ticket with numbers"() {
        given: "a ticket with a 2D list of numbers"
        List<List<Integer>> ticketNumbers = [
                [1, 2, 3],
                [4, 5, 6],
                [7, 8, 9]
        ]
        Ticket ticket = new Ticket(ticketNumbers)

        expect: "the ticket's numbers are correctly initialized"
        ticket.getNumbers() == ticketNumbers
    }

    def "should cross a number correctly"() {
        given: "a ticket with some numbers"
        List<List<Integer>> ticketNumbers = [
                [1, 2, 3],
                [4, 5, 6],
                [7, 8, 9]
        ]
        Ticket ticket = new Ticket(ticketNumbers)

        when: "we cross number 5"
        ticket.crossNumber(5)

        then: "number 5 should be crossed"
        ticket.isNumberCrossed(5) == true
    }

    def "should not cross a number if it's not on the ticket"() {
        given: "a ticket with numbers"
        List<List<Integer>> ticketNumbers = [
                [1, 2, 3],
                [4, 5, 6],
                [7, 8, 9]
        ]
        Ticket ticket = new Ticket(ticketNumbers)

        when: "we try to cross a number not on the ticket"
        ticket.crossNumber(10)

        then: "the crossed numbers set remains unchanged"
        ticket.getCrossedNumbers().size() == 1
    }



}
