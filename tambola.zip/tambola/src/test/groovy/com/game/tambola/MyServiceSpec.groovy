package com.game.tambola
import spock.lang.Specification
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MyServiceSpec extends Specification {


    def "test service logic"() {
        given: "a predefined input"
        def input = 5

        when: "the service method is called"
        def result = 5

        then: "the result should be as expected"
        result == 5
    }
}