package com.game.tambola

import spock.lang.Ignore
import spock.lang.Specification

class ClaimValidatorSpec extends Specification {


    def "should validate 'Top Row' claim "() {
        given: "a ticket with a specific row crossed"
        def ticketNumbers = [
                [4, 16, null, null, 48, null, 63, 76, null],
                [7, null, 23, 38, null, 52, null, null, 80],
                [9, null, 25, null, null, 56, 64, null, 83]
        ]
        def ticket = new Ticket(ticketNumbers)
        def game = new Game(ticket)
        def claimValidator = new ClaimValidator([90, 4, 46, 63, 89, 16, 76, 48], ticket)

        ticket.crossNumber(90)
        ticket.crossNumber(4)
        ticket.crossNumber(46)
        ticket.crossNumber(63)
        ticket.crossNumber(89)
        ticket.crossNumber(76)
        ticket.crossNumber(48)

        when: "the claim is 'Top Row'"
        String result = claimValidator.validateClaim('Top Row')

        then: "the claim is accepted"
        result == 'Accepted'
    }


    def "should validate 'Top Row' Late claim  "() {
        given: "a ticket with a specific row crossed"
        def ticketNumbers = [
                [4, 16, null, null, 48, null, 63, 76, null],
                [7, null, 23, 38, null, 52, null, null, 80],
                [9, null, 25, null, null, 56, 64, null, 83]
        ]
        def ticket = new Ticket(ticketNumbers)
        def game = new Game(ticket)
        def claimValidator = new ClaimValidator([90, 4, 46, 63, 89, 16, 76, 48, 12], ticket)

        ticket.crossNumber(90)
        ticket.crossNumber(4)
        ticket.crossNumber(46)
        ticket.crossNumber(63)
        ticket.crossNumber(89)
        ticket.crossNumber(16)
        ticket.crossNumber(76)
        ticket.crossNumber(48)
        ticket.crossNumber(12)

        when: "the claim is 'Top Row'"
        String result = claimValidator.validateClaim('Top Row')

        then: "the claim is accepted"
        result == 'Rejected'
    }

    def "should validate 'Top Row' claim correctly"() {
        given: "a ticket with a specific row crossed"
        def ticketNumbers = [
                [1, 2, 3, 4, 5],  // top row
                [6, 7, 8, 9, 10], // middle row
                [11, 12, 13, 14, 15] // bottom row
        ]
        def ticket = new Ticket(ticketNumbers)
        def game = new Game(ticket)
        def claimValidator = new ClaimValidator([1, 2, 3, 15], ticket)

        ticket.crossNumber(1)
        ticket.crossNumber(2)
        ticket.crossNumber(3)
        ticket.crossNumber(15)

        when: "the claim is 'Top Row'"
        def result = claimValidator.validateClaim('Top Row')

        then: "the claim is rejected"
        result == 'Rejected'
    }

    def "should reject 'Top Row' claim when not all numbers are crossed"() {
        given: "a ticket with only some numbers crossed"
        def ticketNumbers = [
                [1, 2, 3, 4, 5],  // top row
                [6, 7, 8, 9, 10], // middle row
                [11, 12, 13, 14, 15] // bottom row
        ]
        def ticket = new Ticket(ticketNumbers)
        def claimValidator = new ClaimValidator([1, 2], ticket)

        ticket.crossNumber(1)
        ticket.crossNumber(2)

        when: "the claim is 'Top Row'"
        def result = claimValidator.validateClaim('Top Row')

        then: "the claim is rejected"
        result == 'Rejected'
    }

    def "should validate 'Full House' claim when all numbers are crossed"() {
        given: "a ticket with all numbers crossed"
        def ticketNumbers = [
                [1, 2, 3, 4, 5],  // top row
                [6, 7, 8, 9, 10], // middle row
                [11, 12, 13, 14, 15] // bottom row
        ]
        def ticket = new Ticket(ticketNumbers)
        def claimValidator = new ClaimValidator([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], ticket)

        ticket.crossNumber(1)
        ticket.crossNumber(2)
        ticket.crossNumber(3)
        ticket.crossNumber(4)
        ticket.crossNumber(5)
        ticket.crossNumber(6)
        ticket.crossNumber(7)
        ticket.crossNumber(8)
        ticket.crossNumber(9)
        ticket.crossNumber(10)
        ticket.crossNumber(11)
        ticket.crossNumber(12)
        ticket.crossNumber(13)
        ticket.crossNumber(14)
        ticket.crossNumber(15)

        when: "the claim is 'Full House'"
        def result = claimValidator.validateClaim('Full House')

        then: "the claim is accepted"
        result == 'Accepted'
    }

    def "should reject 'Full House' claim when not all numbers are crossed"() {
        given: "a ticket with only some numbers crossed"
        def ticketNumbers = [
                [1, 2, 3, 4, 5],  // top row
                [6, 7, 8, 9, 10], // middle row
                [11, 12, 13, 14, 15] // bottom row
        ]
        def ticket = new Ticket(ticketNumbers)
        def claimValidator = new ClaimValidator([1, 2, 3, 4, 5], ticket)

        ticket.crossNumber(1)
        ticket.crossNumber(2)
        ticket.crossNumber(3)

        when: "the claim is 'Full House'"
        def result = claimValidator.validateClaim('Full House')

        then: "the claim is rejected"
        result == 'Rejected'
    }

    def "should validate 'Early Five' claim when the first five numbers are crossed"() {
        given: "a ticket where the first 5 numbers are crossed"
        def ticketNumbers = [
                [1, 2, 3, 4, 5],  // top row
                [6, 7, 8, 9, 10], // middle row
                [11, 12, 13, 14, 15] // bottom row
        ]
        def ticket = new Ticket(ticketNumbers)
        def claimValidator = new ClaimValidator([1, 2, 3, 4, 5], ticket)

        ticket.crossNumber(1)
        ticket.crossNumber(2)
        ticket.crossNumber(3)
        ticket.crossNumber(4)
        ticket.crossNumber(5)

        when: "the claim is 'Early Five'"
        def result = claimValidator.validateClaim('Early Five')

        then: "the claim is accepted"
        result == 'Accepted'
    }

    def "should reject 'Early Five' claim if less than five numbers are crossed"() {
        given: "a ticket with less than 5 numbers crossed"
        def ticketNumbers = [
                [1, 2, 3, 4, 5],  // top row
                [6, 7, 8, 9, 10], // middle row
                [11, 12, 13, 14, 15] // bottom row
        ]
        def ticket = new Ticket(ticketNumbers)
        def claimValidator = new ClaimValidator([1, 2, 3], ticket)

        ticket.crossNumber(1)
        ticket.crossNumber(2)
        ticket.crossNumber(3)

        when: "the claim is 'Early Five'"
        def result = claimValidator.validateClaim('Early Five')

        then: "the claim is rejected"
        result == 'Rejected'
    }

    def "should reject unrecognized claim"() {
        given: "a ticket"
        def ticketNumbers = [
                [1, 2, 3, 4, 5],  // top row
                [6, 7, 8, 9, 10], // middle row
                [11, 12, 13, 14, 15] // bottom row
        ]
        def ticket = new Ticket(ticketNumbers)
        def claimValidator = new ClaimValidator([1, 2, 3], ticket)

        when: "an unrecognized claim is provided"
        def result = claimValidator.validateClaim('Unknown Claim')

        then: "the claim is rejected"
        result == 'Rejected'
    }
}
