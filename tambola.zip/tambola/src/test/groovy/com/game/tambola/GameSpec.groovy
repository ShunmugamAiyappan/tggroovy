package com.game.tambola



import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Subject

class GameSpec extends Specification {

    @Subject
    Game game

    def "Test if top line is winning"() {
        given: "A ticket with crossed numbers on the top line"
        Ticket ticket = Mock(Ticket)
        ticket.getNumbers() >> [
                [1, 2, 3, 4, 5],  // top line
                [6, 7, 8, 9, 10], // middle line
                [11, 12, 13, 14, 15] // bottom line
        ]
        ticket.isNumberCrossed(1) >> true
        ticket.isNumberCrossed(2) >> true
        ticket.isNumberCrossed(3) >> true
        ticket.isNumberCrossed(4) >> true
        ticket.isNumberCrossed(5) >> true

        game = new Game(ticket)

        when: "We check if the top line is winning"
        boolean result = game.isTopLine()

        then: "The top line is a winning line"
        result == true
    }

    def "Test if middle line is not winning"() {
        given: "A ticket where not all numbers on the middle line are crossed"
        Ticket ticket = Mock(Ticket)
        ticket.getNumbers() >> [
                [1, 2, 3, 4, 5],
                [6, 7, 8, 9, 10],
                [11, 12, 13, 14, 15]
        ]
        ticket.isNumberCrossed(6) >> true
        ticket.isNumberCrossed(7) >> false
        ticket.isNumberCrossed(8) >> true
        ticket.isNumberCrossed(9) >> false
        ticket.isNumberCrossed(10) >> true

        game = new Game(ticket)

        when: "We check if the middle line is winning"
        boolean result = game.isMiddleLine()

        then: "The middle line is not a winning line"
        result == false
    }

    def "Test if bottom line is winning"() {
        given: "A ticket with crossed numbers on the bottom line"
        Ticket ticket = Mock(Ticket)
        ticket.getNumbers() >> [
                [1, 2, 3, 4, 5],
                [6, 7, 8, 9, 10],
                [11, 12, 13, 14, 15]
        ]
        ticket.isNumberCrossed(11) >> true
        ticket.isNumberCrossed(12) >> true
        ticket.isNumberCrossed(13) >> true
        ticket.isNumberCrossed(14) >> true
        ticket.isNumberCrossed(15) >> true

        game = new Game(ticket)

        when: "We check if the bottom line is winning"
        boolean result = game.isBottomLine()

        then: "The bottom line is a winning line"
        result == true
    }

    def "Test if ticket is a full house"() {
        given: "A ticket where all numbers are crossed"
        Ticket ticket = Mock(Ticket)
        ticket.getNumbers() >> [
                [1, 2, 3, 4, 5],
                [6, 7, 8, 9, 10],
                [11, 12, 13, 14, 15]
        ]
        ticket.isNumberCrossed(1) >> true
        ticket.isNumberCrossed(2) >> true
        ticket.isNumberCrossed(3) >> true
        ticket.isNumberCrossed(4) >> true
        ticket.isNumberCrossed(5) >> true
        ticket.isNumberCrossed(6) >> true
        ticket.isNumberCrossed(7) >> true
        ticket.isNumberCrossed(8) >> true
        ticket.isNumberCrossed(9) >> true
        ticket.isNumberCrossed(10) >> true
        ticket.isNumberCrossed(11) >> true
        ticket.isNumberCrossed(12) >> true
        ticket.isNumberCrossed(13) >> true
        ticket.isNumberCrossed(14) >> true
        ticket.isNumberCrossed(15) >> true

        game = new Game(ticket)

        when: "We check if the ticket is a full house"
        boolean result = game.isFullHouse()

        then: "The ticket is a full house"
        result == true
    }

    def "Test if ticket is not a full house"() {
        given: "A ticket where not all numbers are crossed"
        Ticket ticket = Mock(Ticket)
        ticket.getNumbers() >> [
                [1, 2, 3, 4, 5],
                [6, 7, 8, 9, 10],
                [11, 12, 13, 14, 15]
        ]
        ticket.isNumberCrossed(1) >> true
        ticket.isNumberCrossed(2) >> true
        ticket.isNumberCrossed(3) >> false
        ticket.isNumberCrossed(4) >> true
        ticket.isNumberCrossed(5) >> false
        ticket.isNumberCrossed(6) >> true
        ticket.isNumberCrossed(7) >> false
        ticket.isNumberCrossed(8) >> false
        ticket.isNumberCrossed(9) >> true
        ticket.isNumberCrossed(10) >> false
        ticket.isNumberCrossed(11) >> true
        ticket.isNumberCrossed(12) >> true
        ticket.isNumberCrossed(13) >> false
        ticket.isNumberCrossed(14) >> false
        ticket.isNumberCrossed(15) >> false

        game = new Game(ticket)

        when: "We check if the ticket is a full house"
        boolean result = game.isFullHouse()

        then: "The ticket is not a full house"
        result == false
    }

    def "Test if early five claim is true"() {
        given: "A ticket with exactly five crossed numbers in the first five positions"
        Ticket ticket = Mock(Ticket)
        ticket.getCrossedNumbers() >> [1, 2, 3, 4, 5, 6, 7]
        ticket.getNumbers() >> [
                [1, 2, 3, 4, 5],
                [6, 7, 8, 9, 10],
                [11, 12, 13, 14, 15]
        ]

        game = new Game(ticket)

        when: "We check if the early five claim is true"
        boolean result = game.isEarlyFive()

        then: "The early five claim is true"
        result == true
    }

    def "Test if early five claim is false"() {
        given: "A ticket with less than five crossed numbers in the first five positions"
        Ticket ticket = Mock(Ticket)
        ticket.getCrossedNumbers() >> [1, 2, 3]
        ticket.getNumbers() >> [
                [1, 2, 3, 4, 5],
                [6, 7, 8, 9, 10],
                [11, 12, 13, 14, 15]
        ]

        game = new Game(ticket)

        when: "We check if the early five claim is true"
        boolean result = game.isEarlyFive()

        then: "The early five claim is false"
        result == false
    }
}
